/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albben-a <albben-a@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/30 08:44:03 by albben-a          #+#    #+#             */
/*   Updated: 2026/01/30 10:09:19 by albben-a         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
	t_list	*start;
	t_list	*node;
	void	*new_content;

	start = NULL;
	while (lst != NULL)
	{
		new_content = f(lst->content);
		node = ft_lstnew(new_content);
		if (!node)
		{
			ft_lstclear(&start, del);
			return (NULL);
		}
		ft_lstadd_back(&start, node);
		lst = lst->next;
	}
	return (start);
}
/*
void	*ft_upper(void *content)
{
	int	i;
	char	*s;

	i = 0;
	s = ft_strdup(content);
	while (s[i] != '\0')
	{
		if ('a' <= s[i] && s[i] <= 'z')
			s[i] = s[i] - 32;
		i++;
	}
	return ((void *)s);
}

void	ft_del(void *content)
{
	free(content);
}

#include <stdio.h>

int	main(void)
{
	t_list	*list;
	t_list	*new;

	t_list	*node2;
	t_list	*node3;
	t_list	*node4;
	char	content_test[] = "test";

	list = ft_lstnew(content_test);
	node2 = ft_lstnew(content_test);
	node3 = ft_lstnew(content_test);
	node4 = ft_lstnew(content_test);

	ft_lstadd_front(&list, node4);
	ft_lstadd_front(&list, node3);
	ft_lstadd_front(&list, node2);

	printf("%s\n", (char *) list->content);
	new = ft_lstmap(list, ft_upper, ft_del);
	printf("%s", (char *) new->content);
	return (0);
}*/
